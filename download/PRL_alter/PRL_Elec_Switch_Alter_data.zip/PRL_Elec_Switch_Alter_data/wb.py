import wannierberri as wberri
print (f"Using WannierBerri version {wberri.__version__}")
import numpy as np
from wannierberri.smoother import FermiDiracSmoother
import matplotlib.pyplot as plt
plt.switch_backend('agg')


s1 = np.zeros( (42) )
s1[:6] += 1
s1[21:27] += 1

s2 = np.zeros( (42) )
s2[6:12] += 1
s2[27:33] += 1

s3 = np.zeros( (42) )
s3[12:21] += 1
s3[33:42] += 1



parallel = wberri.Parallel()
Ef = np.array(np.linspace(-1.195-0.5,-1.195+0.5,1001))
#Ef = np.array([4.97])

#m = 90
#n = 0
nk = 1200
#for nk in [150]:
#if True:
for m in [90]:
    for n in [0,15,30,45,60,75,90,105,120,135,150,165,180]:
    #for n in [135,150,165,180]:
    #for n in [180]:
        system=wberri.System_tb(
                        '../wannier90_tb_{}{}.dat'.format(m,n),
                        berry=True,
                        periodic=[True,True,False]
                        )

        system.set_spin_from_code(DFT_code="vasp")

        system._XX_R['SS'] *= s1[:,None,None,None]
        system._XX_R['SS'] *= s1[None,:,None,None]

        calculators = {
                "nfscum":wberri.calculators.static.NFSCUM( degen_thresh=1e-2,Efermi=Ef,tetra=True,smoother=FermiDiracSmoother(Ef, T_Kelvin=50, maxdE=8)),
                #"scum":wberri.calculators.static.SCUM( Efermi=Ef,tetra=True,smoother=FermiDiracSmoother(Ef, T_Kelvin=50, maxdE=8)),
                #'Spin':wberri.calculators.static.Spin( Efermi=Ef,tetra=True,smoother=FermiDiracSmoother(Ef, T_Kelvin=50, maxdE=8)),
                         }
        grid = wberri.Grid(system, NK=nk)
        #grid = wberri.Grid(system, NK=100)
        result_run = wberri.run(system,
                grid=grid,
                calculators = calculators,
                adpt_num_iter=100,
                parallel = parallel,
                fout_name='S1_{}{}-{}'.format(m,n,nk),
                restart=False,
                )
