#!/bin/bash
#BSUB -J vary_m_MnTe
#BSUB -q short
#BSUB -n 40
#BSUB -R "span[ptile=40]"
#BSUB -e job.err
#BSUB -o job.out
#BSUB -W 84:20


module load gcc/9.3.0 intel/2018.4 mpi/intel/2018.4

module load vasp/5.4.4.wannier90.2.1
#python wb.py >out&
#mpirun wt.x &>out

for theta in 90;
do
#for phi in 0 15 30 45 60 75 90 105 120;
for phi in 5 10 20 25 35 40 50 55 65 70 80 85 95 100 110 115;
#for phi in 135 150 165 180;
do
mkdir tp$theta$phi
cd tp$theta$phi

cp ../* ./
rm wannier90*
rm CHGCAR
python3 m_angle.py spin2CHGCAR $theta $phi

python3 incarI.py $theta $phi >INCAR
mpirun vasp_ncl &>out

mkdir bands
cd bands

cp ../* ./
cp ../../incarL.py ./
cp ../../KPOINTSL ./KPOINTS
cp ../../plot_compare.py ./
python3 incarL.py $theta $phi >INCAR
mpirun vasp_ncl &>out

cd ..

cp ../incar.py ./
cp ../wannier90.win ./
cp ../hrtb ./
python3 incar.py $theta $phi >INCAR

mpirun vasp_ncl &>out

cat wannier90.win hrtb > wannout
cp wannout wannier90.win
/data/phy-luhz/xxliu/wannier90/wannier90.x wannier90

cp wannier90_tb.dat wannier90_tb_$theta$phi.dat

cp wannier90_band.dat ./bands/

cd ./bands
python3 plot_compare.py

cp band.png band$theta$phi.png

cd ..
cd ..
done
done


echo "End at :"
date
